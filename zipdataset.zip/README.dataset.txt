# My First Project > 2025-02-19 9:52pm
https://universe.roboflow.com/try-jtjar/my-first-project-n94vd

Provided by a Roboflow user
License: CC BY 4.0

